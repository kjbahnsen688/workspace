//kelsey 1/22 github
public class hello {

	public static void main(String[] args) {
		System.out.println ("i got a new laptop so i don't have my first folder");
		System.out.println ("hopefully this will fulfill this assignment");

	}

}
